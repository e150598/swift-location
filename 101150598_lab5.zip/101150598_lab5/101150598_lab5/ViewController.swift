//
//  ViewController.swift
//  101150598_lab5
//
//  Created by Tech on 2021-02-22.
//  Copyright © 2021 Tech. All rights reserved.
//

import UIKit
import MapKit
import CoreMotion
import CoreLocation


internal class ViewController : UIViewController, CLLocationManagerDelegate {
    
    @IBOutlet weak internal var mapKit: MKMapView!
    
    @IBOutlet weak internal var label2: UILabel!
    
    @IBOutlet weak internal var label1: UILabel!
    
    var motionManager: CMMotionManager!
    
    var locationManager: CLLocationManager!
    
    var timer:Timer!
    
    override internal func viewDidLoad(){
        
        motionManager = CMMotionManager()
        if motionManager.isAccelerometerAvailable{
            motionManager.accelerometerUpdateInterval = 1.0/60.0
            
            motionManager.startAccelerometerUpdates()
            
            
            timer = Timer(fire: Date(), interval: (1.0/60.0), repeats: true, block: {(timer) in
                if let data = self.motionManager.accelerometerData{
                    self.label1.text = String(data.acceleration.x)
                     self.label2.text = String(data.acceleration.y)
                    
                }
            
        })
        
        }else{
            print("Accelerometr is not availabler")
        }
        locationManager = CLLocationManager()
        locationManager.delegate = self
        
        locationManager.requestAlwaysAuthorization()
        locationManager.startUpdatingLocation()
}
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        for l in locations{
           // map.centerCoordinate = l.coordinate
            label1.text = String(l.coordinate.latitude)
            label2.text = String(l.coordinate.longitude)
            
            let region = MKCoordinateRegion(
                center: l.coordinate,
                latitudinalMeters: 100,
                longitudinalMeters: 100)
            mapKit.setRegion(region, animated: true)
            mapKit.addAnnotation(PointOfInterest(location: l.coordinate, title: "moved here"))
         
        }
    }
}

class PointOfInterest: NSObject,MKAnnotation{
    var coordinate: CLLocationCoordinate2D
    var title: String?
    
    init(location: CLLocationCoordinate2D, title: String){
        self.coordinate = location
        self.title = title
    }
}
